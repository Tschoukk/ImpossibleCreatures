<?php
use Illuminate\Http\Request;
Route::group([
    'prefix' => 'auth'
], function () {
    Route::post('login', 'AuthController@login');
    Route::post('signup', 'AuthController@signup');
  
    Route::group([
      'middleware' => 'auth:api'
    ], function() {
        Route::get('logout', 'AuthController@logout');
        Route::get('user', 'AuthController@user');
    });
});


Route::get('/species', 'SpeciesController@index');
Route::post('/species/store', 'SpeciesController@store');
Route::get('/species/{id?}', 'SpeciesController@show');
Route::post('/species/update/{id?}', 'SpeciesController@update');
Route::delete('/species/{id?}', 'SpeciesController@destroy');

Route::get('/animals/owner/{id?}', 'AnimalsController@show_animals_owner');

Route::get('/animals/user/score', 'AnimalsController@user_score');

Route::get('/animals', 'AnimalsController@index');
Route::post('/animals/store', 'AnimalsController@store');
Route::get('/animals/{id?}', 'AnimalsController@show');
Route::post('/animals/update/{id?}', 'AnimalsController@update');
Route::delete('/animals/{id?}', 'AnimalsController@destroy');