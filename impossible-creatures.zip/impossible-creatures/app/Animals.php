<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Animals extends Model
{
    protected $fillable = [
        'species', 'user_id_creator', 'user_id_owner'
    ];
}
