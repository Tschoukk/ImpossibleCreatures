<?php
namespace App\Http\Controllers;
use App\Animals;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class AnimalsController extends Controller
{
	public function index()
	{
		$posts = Animals::latest()->get();
		return response([
			'success' => true,
			'data' => $posts
		], 200);
	}
	public function store(Request $request)
	{
        //validate data
		$validator = Validator::make($request->all(), [
			'species' => 'required',
			'user_id_creator' => 'required',
			'user_id_owner' => 'required'
		],
		[
			'species.required' => 'Enter Name Species! ',
			'user_id_creator.required' => 'user id owner required',
			'user_id_owner.required' => 'user id owner required',
		]
	);
		if($validator->fails()) {
			return response()->json([
				'success' => false,
				'message' => 'Please fill in the blank fields',
				'data'    => $validator->errors()
			],400);
		} else {
			$post = Animals::create([
				'species'     => $request->input('species'),
				'user_id_creator'   => $request->input('user_id_creator'),
				'user_id_owner'   => $request->input('user_id_owner')
			]);
			if ($post) {
				return response()->json([
					'success' => true,
					'message' => 'Animal Saved! ',
				], 200);
			} else {
				return response()->json([
					'success' => false,
					'message' => 'Animal Failed to Save!',
				], 400);
			}
		}
	}

	public function show($id)
	{
		$post = Animals::where('user_id_creator', '=', $id)->orWhere('user_id_owner', '=', $id)->get();
		if ($post) {
			return response()->json([
				'success' => true,				
				'data'    => $post
			], 200);
		} else {
			return response()->json([
				'success' => false,
				'message' => 'Animals Not Found!',
				'data'    => ''
			], 404);
		}
	}

	public function user_score()
	{
		$post = User::select('users')->max('score');
		if ($post) {
			return response()->json([
				'success' => true,				
				'data'    => $post
			], 200);
		} else {
			return response()->json([
				'success' => false,
				'message' => 'Score have value 0',
				'data'    => ''
			], 404);
		}
	}

	

	public function show_animals_owner($id)
	{
        $post = Animals::leftJoin('users', 'users.id', '=', 'animals.user_id_owner')->select('users.*')->distinct()->get();
		if ($post) {
			return response()->json([
				'success' => true,				
				'data'    => $post
			], 200);
		} else {
			return response()->json([
				'success' => false,
				'message' => 'Animals Not Found!',
				'data'    => ''
			], 404);
		}
	}

	public function update(Request $request)
	{
        //validate data
		$validator = Validator::make($request->all(), [
			'species'     => 'required',
			'user_id_creator'   => 'required',
		],
		[
			'species.required' => 'Enter a species',
			'user_id_creator.required' => 'Enter an id',
		]
	);
		if($validator->fails()) {
			return response()->json([
				'success' => false,
				'message' => 'Please fill in the blank fields',
				'data'    => $validator->errors()
			],400);
		} else {
			$post = Animals::whereId($request->input('id'))->update([
				'species'     => $request->input('species'),
				'user_id_creator'   => $request->input('user_id_creator'),
				'user_id_owner'   => $request->input('user_id_owner')
			]);
			if ($post) {
				return response()->json([
					'success' => true,
					'message' => 'Animal Updated successfully!',
				], 200);
			} else {
				return response()->json([
					'success' => false,
					'message' => 'Animal Failed to Update!',
				], 500);
			}
		}
	}
	public function destroy($id)
	{
		$post = Animal::findOrFail($id);
		$post->delete();
		if ($post) {
			return response()->json([
				'success' => true,
				'message' => 'Animal Successfully Deleted!',
			], 200);
		} else {
			return response()->json([
				'success' => false,
				'message' => 'Animal Failed to Delete!',
			], 500);
		}
	}
}

