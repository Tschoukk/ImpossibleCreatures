<?php
namespace App\Http\Controllers;
use App\Species;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class SpeciesController extends Controller
{
	public function index()
	{
		$posts = Species::latest()->get();
		return response([
			'success' => true,
			'data' => $posts
		], 200);
	}
	public function store(Request $request)
	{
        //validate data
		$validator = Validator::make($request->all(), [
			'name' => 'required',
			'user_id_creator' => 'required',
		],
		[
			'name.required' => 'Enter Name Species! ',
			'user_id_creator.required' => 'user id creator required',
		]
	);
		if($validator->fails()) {
			return response()->json([
				'success' => false,
				'message' => 'Please fill in the blank fields',
				'data'    => $validator->errors()
			],400);
		} else {
			$post = Species::create([
				'name'     => $request->input('name'),
				'user_id_creator'   => $request->input('user_id_creator')
			]);
			if ($post) {
				return response()->json([
					'success' => true,
					'message' => 'Species Saved! ',
				], 200);
			} else {
				return response()->json([
					'success' => false,
					'message' => 'Post Failed to Save!',
				], 400);
			}
		}
	}
	public function show($id)
	{
		$post = Species::where('user_id_creator', '=', $id);
		if ($post) {
			return response()->json([
				'success' => true,				
				'data'    => $post
			], 200);
		} else {
			return response()->json([
				'success' => false,
				'message' => 'Post Not Found!',
				'data'    => ''
			], 404);
		}
	}
	public function update(Request $request)
	{
        //validate data
		$validator = Validator::make($request->all(), [
			'name'     => 'required',
			'user_id_creator'   => 'required',
		],
		[
			'name.required' => 'Enter a name',
			'user_id_creator.required' => 'Enter an id',
		]
	);
		if($validator->fails()) {
			return response()->json([
				'success' => false,
				'message' => 'Please fill in the blank fields',
				'data'    => $validator->errors()
			],400);
		} else {
			$post = Species::whereId($request->input('id'))->update([
				'name'     => $request->input('name'),
				'user_id_creator'   => $request->input('user_id_creator'),
			]);
			if ($post) {
				return response()->json([
					'success' => true,
					'message' => 'Species Updated successfully!',
				], 200);
			} else {
				return response()->json([
					'success' => false,
					'message' => 'Species Failed to Update!',
				], 500);
			}
		}
	}
	public function destroy($id)
	{
		$post = Species::findOrFail($id);
		$post->delete();
		if ($post) {
			return response()->json([
				'success' => true,
				'message' => 'Species Successfully Deleted!',
			], 200);
		} else {
			return response()->json([
				'success' => false,
				'message' => 'Species Failed to Delete!',
			], 500);
		}
	}
}

